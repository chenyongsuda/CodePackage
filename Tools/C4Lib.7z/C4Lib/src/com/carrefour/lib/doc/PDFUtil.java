package com.carrefour.lib.doc;

import java.io.FileOutputStream;
import java.util.ArrayList;

import com.carrefour.bin.PDFRow;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PDFUtil {
	
	//header
	private ArrayList<String> PDFHeader;
	//content
	private ArrayList<PDFRow> PDFContent;
	//set header width
	private ArrayList PDFHeaderWidth;
	//Set header font size
	private int headFontSize = 26;
	//set Header font color
	private BaseColor headerFontColor = BaseColor.BLACK;
	//set headee bk color
	private BaseColor headerBKcolor = BaseColor.WHITE;
	//Set Content font size
	private int contentFontSize = 18;
	
    // ���������
    private static final int spacing = 2;
    // ���������
    private static final int padding = 2;
    
	public static void main(String[] args) {
		ArrayList<String> PDFHeader = new ArrayList<String>();
		PDFHeader.add("Header1");
		PDFHeader.add("Header2");
		PDFHeader.add("Header3");
		
		ArrayList<PDFRow> PDFContent = new ArrayList<PDFRow>();
		for(int i = 0 ; i < 10; i++)
		{
			PDFRow row = new PDFRow();
			ArrayList<String> rowData = new ArrayList<String>();
			rowData.add("date1 " + i);
			rowData.add("date2 " + i);
			rowData.add("date3 " + i);
			if(0 == i%2)
			{
				row.setRowFontColor(BaseColor.RED);
				row.setRowBKColor(BaseColor.YELLOW);
			}
			row.setRowData(rowData);
			PDFContent.add(row);
		}
		PDFUtil pdf = new PDFUtil();
		pdf.setPDFHeaderList(PDFHeader);
		pdf.setPDFContentList(PDFContent);
		pdf.exportPdfDocument("D:/TEST.PDF");
	}
	//set Header
	public void setPDFHeaderList(ArrayList<String> PDFHeader)
	{
		this.PDFHeader = PDFHeader;
	}
	//set Content
	public void setPDFContentList(ArrayList<PDFRow> PDFContent)
	{
		this.PDFContent = PDFContent;
	}
	//set width percent
	public void setPDFHeaderWidth(ArrayList PDFHeaderWidth)
	{
		this.PDFHeaderWidth = PDFHeaderWidth;
	}
	//Set header font size
	public void setPDFHeadFontSize(int headFontSize) {
		this.headFontSize = headFontSize;
	}
	//Set Content font size
	public void setPDFContentFontSize(int contentFontSize) {
		this.contentFontSize = contentFontSize;
	}
	//set header font color
	public void setPDFHeaderFontColor(BaseColor headerFontColor) {
		this.headerFontColor = headerFontColor;
	}
	public void setPDFHeaderBKcolor(BaseColor headerBKcolor) {
		this.headerBKcolor = headerBKcolor;
	}
	
	// ����Pdf�ĵ�
    public void exportPdfDocument(String path) {
           // ������Pdf�ĵ�50, 50, 50,50�������¾���
           Document document = new Document(new Rectangle(1500, 2000), 50, 50, 50,
                         50);
           try {
                  //ʹ��PDFWriter����д�ļ�����
                  PdfWriter.getInstance(document,new FileOutputStream(path));
                  
                  document.open();
                  // ������colNumber(6)�еı���
                  PdfPTable datatable = new PdfPTable(PDFHeader.size());
                  //�������Ŀ���
                  if(null != PDFHeaderWidth)
                  {
                	  int len = PDFHeaderWidth.size();
                	  int[] cellsWidth = new int[len];
                	  for(int i = 0; i < len; i++)
                	  {
                		  cellsWidth[i]= (Integer)PDFHeaderWidth.get(i);
                	  }
                	  datatable.setWidths(cellsWidth);
                  }
                  // ����Ŀ��Ȱٷֱ�
                  datatable.setWidthPercentage(100);
                  datatable.getDefaultCell().setPadding(padding);
                  datatable.getDefaultCell().setBorderWidth(spacing);
                  
                  //���ñ���ĵ�ɫ
                  // ��������
                  BaseFont bfChinese =BaseFont.createFont("STSong-Light",
                                "UniGB-UCS2-H",BaseFont.NOT_EMBEDDED);
                  Font fontChinese = new Font(bfChinese, headFontSize, Font.BOLD,headerFontColor);
                  datatable.getDefaultCell().setBackgroundColor(headerBKcolor);
                  datatable.getDefaultCell().setHorizontalAlignment(
                                Element.ALIGN_CENTER);
                  datatable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
                  // ���ӱ�ͷԪ��
                  for (int i = 0; i < PDFHeader.size(); i++) {
                         datatable.addCell(new Paragraph(PDFHeader.get(i), fontChinese));
                  }
                  
                  // ������Ԫ��
                  for(int row = 0; row < PDFContent.size(); row++)
                  {
                	  PDFRow rowContent = PDFContent.get(row);
                	  //init the color setting
                	  // ��������
                      BaseFont bfChineseContent =BaseFont.createFont("STSong-Light",
                                    "UniGB-UCS2-H",BaseFont.NOT_EMBEDDED);
                      Font fontChineseContent = new Font(bfChineseContent, contentFontSize, Font.NORMAL,rowContent.getRowFontColor());
                      
                      //���ñ���ĵ�ɫ
//                      datatable.getDefaultCell().setBackgroundColor(rowContent.getRowBKColor());
//                      datatable.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//                      datatable.getDefaultCell().setVerticalAlignment(Element.ALIGN_CENTER);
                	  for(int col = 0; col < rowContent.getRowData().size(); col++)
                	  {
                		  PdfPCell cell = new PdfPCell(new Paragraph(rowContent.getRowData().get(col), fontChineseContent));
                		  cell.setMinimumHeight(30f);
                		  cell.setVerticalAlignment(Element.ALIGN_CENTER);
                		  cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                		  cell.setBackgroundColor(rowContent.getRowBKColor());
                		  datatable.addCell(cell);
                	  }
                  }
                  
                  document.add(datatable);
           } catch (Exception e) {
                  e.printStackTrace();
           }
           document.close();
    }
}
