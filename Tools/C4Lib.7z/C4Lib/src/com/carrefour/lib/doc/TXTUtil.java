package com.carrefour.lib.doc;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.io.FileOutputStream;


public class TXTUtil {
	
	public static void main(String[] args) {
		
	}
	
	/**
	 * TXT file util
	 */
	//����һ��һ�е�������һ��list
	public static ArrayList<String> readLine(String filePath) {  
        BufferedReader in = null;  
        ArrayList<String> result = new ArrayList<String>();
        try {  
            in = new BufferedReader(new FileReader(filePath));  
            String s;  
            try {  
                while ((s = in.readLine()) != null)  
                	result.add(s);
            } finally {  
                in.close();  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        return result;
    }
	
	//�����ļ���������ַ���
	public static String readAll(String filePath) { 
        StringBuilder str = new StringBuilder();  
        BufferedReader in = null;  
        try {  
            in = new BufferedReader(new FileReader(filePath));  
            String s;  
            try {  
                while ((s = in.readLine()) != null)  
                    str.append(s + '\n');  
            } finally {  
                in.close();  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        return str.toString();  
    }
	
	// д��ָ�����ı��ļ���appendΪtrue��ʾ׷�ӣ�false��ʾ��ͷ��ʼд��  
    //text��Ҫд����ı��ַ�����textΪnullʱֱ�ӷ���  
    public static void write(String filePath, boolean append, String text) {  
        if (text == null)  
            return;  
        try {  
            BufferedWriter out = new BufferedWriter(new FileWriter(filePath,  
                    append));  
            try {  
                out.write(text);  
            } finally {  
                out.close();  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
    }
}
