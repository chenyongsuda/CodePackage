package com.carrefour.lib.sms;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 * JDBC connection
 * @author walter.xu
 *
 */
public abstract class BaseConnection {

	public Connection getConn() {
		try {
			Class.forName(Const.JDBC_DRIVER);
			return DriverManager.getConnection(Const.JDBC_URL,
					Const.JDBC_USERNAME, Const.JDBC_PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
//		use c3p0
//		try {
//			return C3P0Util.getInstance().getConnection();
//		} catch (SQLException e) {
//			return null;
//		}
	}

	public void closeConn(Connection conn) {
		if (conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}
}
