package com.carrefour.lib.sms;

public class Const {
	// JDBC configuration
	public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	public static final String JDBC_URL = "jdbc:mysql://10.151.245.27:3306/mas?rewriteBatchedStatements=true&characterEncoding=GB2312";
	public static final String JDBC_USERNAME = "sh";
	public static final String JDBC_PASSWORD = "sh2012SH";
	// default password of user
	public static final String DEFAULT_PASSWORD = "smsC@rref0urChina";

	public static final boolean TESTING = false;

	// default of SMTP SERVER
	public static final int SMTP_PORT = 8025;
	public static final String SMTP_SERVERNAME = "10.151.245.27";//10.151.245.27
	public static final String SMTP_SERVERNAME_TEST = "localhost";
	public static final int SMTP_PORT_TEST = 8025;
	
	// SMS Channel Define 
	public static final String SMS_CHANNEL_MAS = "0";
	public static final String SMS_CHANNEL_ET = "1";
	public static final String SMS_CHANNEL_CU = "2";
	
	// SMS Send Type Define
	public static final long SMS_TYPE_MUTI = 100;
}
