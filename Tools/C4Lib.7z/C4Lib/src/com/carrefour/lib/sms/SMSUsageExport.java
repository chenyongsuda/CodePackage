package com.carrefour.lib.sms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SMSUsageExport extends BaseConnection{

	public static void main(String[] args) {
		SMSUsageExport exp =  new SMSUsageExport();
		exp.dosomthing();
	}
	
	public boolean dosomthing()
	{
		Connection conn = null;
		try {
			conn = getConn();
			//String sql = "SELECT mobile,content  from sms_detail where optTime between '2016-02-01' and '2016-03-01' and (CONVERT(mobile/100000000,UNSIGNED) in (130,131,132,145,155,156,176,185,186))";
			String sql = "SELECT mobile,content  from sms_detail where optTime between '2016-03-01' and '2016-04-01'";
			PreparedStatement prest = conn
					.prepareStatement(sql);
			ResultSet rs = prest.executeQuery();
			int shortCount = 0;
			int longCount = 0;
			while (rs.next()) {
				String mobile = rs.getString(2);
				String content = rs.getString(2);
				byte[] messageUCS2  = content.getBytes("iso-10646-ucs-2");
				if(messageUCS2.length > 140) {
					int messageCount = ( messageUCS2.length / (134)) + 1;
//					longCount+=messageCount;
					longCount++;
				}
				else
				{
					shortCount++;
				}
			}
			System.out.println("SHORT:"+shortCount+"    LONG:"+longCount);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeConn(conn);
		}
		return false;
	}

}
