package com.alibaba.middleware.race.mom;

public enum MessageType {
	PUBLISH,
	SUBSCRIBE,
	MsgRecv,
	ACK,
	NACK,
	NONE
}

