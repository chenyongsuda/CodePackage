package com.alibaba.middleware.race.mom;

public enum ConsumeStatus {
	SUCCESS,
	FAIL
}
