package com.alibaba.middleware.race.mom;

public enum SendStatus {
	SUCCESS,
	FAIL
}
