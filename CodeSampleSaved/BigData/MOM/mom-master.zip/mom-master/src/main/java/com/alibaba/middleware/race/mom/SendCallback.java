package com.alibaba.middleware.race.mom;

public interface SendCallback {
	void onResult(SendResult result);
}
