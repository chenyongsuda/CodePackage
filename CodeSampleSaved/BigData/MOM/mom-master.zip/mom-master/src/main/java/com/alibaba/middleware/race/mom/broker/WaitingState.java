package com.alibaba.middleware.race.mom.broker;

public enum WaitingState {
	SUCCESS,
	FAIL,
	WAITING
}