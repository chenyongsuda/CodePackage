package com.dbConsurrent;

import java.util.LinkedList;

public class ConnectPool {
	private LinkedList<Connect> pool = new LinkedList<Connect>();
	
	public ConnectPool(int init_size){
		for(int i=0; i < init_size; i++){
			pool.addLast(ConnectDriver.CreateConnect());
		}
	}
	
	public int size(){
		return pool.size();
	}
	
	public Connect Fetch(long millesecone) throws InterruptedException{
		synchronized (pool) {
			if(millesecone <= 0){
				//don't have time limit
				if(pool.size()<=0){
					pool.wait();
				}
				return pool.removeFirst();
			}
			else{
				long future = System.currentTimeMillis() + millesecone;
				long remain = millesecone;
				while(pool.size()<=0&&remain>0){
					pool.wait(remain);
					remain= future - System.currentTimeMillis(); 
				}
				Connect result = null;
				if(pool.size()>0){
					result = pool.removeFirst();
//					System.out.println(Thread.currentThread().getName()+"Got One,Reamain:"+pool.size());
				}
				return result;
			}
		}
	}
	
	public void Release(Connect con){
		if(null == con){
			return;
		}
		synchronized (pool) {
			pool.addLast(con);
			pool.notifyAll();
		}
	}
}
