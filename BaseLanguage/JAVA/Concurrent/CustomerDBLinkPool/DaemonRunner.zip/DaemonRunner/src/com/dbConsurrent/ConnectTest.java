package com.dbConsurrent;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

public class ConnectTest {
	public static void main(String[] args) {
		int thread = 10;
		final ConnectPool pool = new ConnectPool(10);
		int percount = 10;
		CountDownLatch begin = new CountDownLatch(1);
		CountDownLatch end = new CountDownLatch(thread);
		AtomicInteger get = new AtomicInteger(0);
		AtomicInteger nget = new AtomicInteger(0);
		
		for(int i = 0; i <thread; i++){
			Thread tr = new Thread(new ConnectConsumer(pool, begin, end, get, nget, percount),"Thread-"+i);
			tr.start();
		}
		System.out.println("Test Begin");
		begin.countDown();
		
//		Thread time = new Thread(new Runnable() {
//			public void run() {
//				while(true){
//				try {
//					Thread.sleep(2000);
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
//				System.out.println("PoolSize: " + pool.size());
//				}
//			}
//		});
//		time.setDaemon(true);
//		time.start();
		
		try {
			end.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Test End");
		System.out.println("Test End Got: "+get.get());
		System.out.println("Test End NGot: "+nget.get());
	}
}
