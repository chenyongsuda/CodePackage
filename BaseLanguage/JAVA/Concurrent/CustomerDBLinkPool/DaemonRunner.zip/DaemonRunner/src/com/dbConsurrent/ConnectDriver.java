package com.dbConsurrent;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class ConnectDriver {
	public static Connect CreateConnect(){
		return (Connect) Proxy.newProxyInstance(ConnectDriver.class.getClassLoader(), new Class<?>[]{Connect.class}, new InvocationHandler() {
			public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				if(method.getName().equals("commit")){
					Thread.sleep(100);
//					System.out.println("Walit.....");
				}
				return null;
			}
		});
	}
}
