package com.dbConsurrent;

import java.sql.Time;
import java.util.Scanner;

public class DaemonRunner implements Runnable {
    public void run() {
    	while(true){
    	try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			System.out.println("Catch Interrupt1111");
			e.printStackTrace();
		}
    	}
    }
    
	public static void main(String[] args) {
		Thread dr = new Thread(new DaemonRunner());
		dr.start();
		try {
			Thread.sleep(5000);dr.interrupt();
		} catch (InterruptedException e) {
			System.out.println("Catch Interrupt2222");
			e.printStackTrace();
		}
		
		System.out.println(dr.isInterrupted());
		
	}
}