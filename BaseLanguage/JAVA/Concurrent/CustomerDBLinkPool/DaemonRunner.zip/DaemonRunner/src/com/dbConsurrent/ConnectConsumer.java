package com.dbConsurrent;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

public class ConnectConsumer implements Runnable{

	private ConnectPool pool;
	private CountDownLatch begin;
	private CountDownLatch end;
	private AtomicInteger get;
	private AtomicInteger nget;
	private int count;
	public ConnectConsumer(ConnectPool pool,CountDownLatch bg, CountDownLatch ed,AtomicInteger get, AtomicInteger nget,int count){
		begin = bg;
		end = ed;
		this.get = get;
		this.nget = nget;
		this.count = count;
		this.pool = pool;
	}
	
	public void run() {
		
		try {
			begin.await();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		
		System.out.println(Thread.currentThread().getName()+" BeginRun!!!");
		
		while(count>0){
			Connect con = null;
			try {
				con = pool.Fetch(1000);
				if(null == con){
					nget.incrementAndGet();
				}
				else{
					get.incrementAndGet();
					con.commit();
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.Release(con);
			}
			count--;
		}
		end.countDown();
	}

}
