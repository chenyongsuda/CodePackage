package com.dbConsurrent;

public interface Connect {
	void commit();
}
