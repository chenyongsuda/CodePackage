package com.sk.IF;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.AdaptiveRecvByteBufAllocator;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.TimeUnit;

public class RPCConsumer {
	private Bootstrap bp;
	private RPCConnection con;
	
	public RPCConsumer(){
		init();
		doConnect();
	}
	
	public void init(){
		NioEventLoopGroup childGroup = new NioEventLoopGroup();
		bp = new Bootstrap();
		bp.group(childGroup)
		.channel(NioSocketChannel.class)
		.option(ChannelOption.TCP_NODELAY, false)
		.option(ChannelOption.SO_KEEPALIVE, true)
		.option(ChannelOption.RCVBUF_ALLOCATOR, new AdaptiveRecvByteBufAllocator(64,80,65535))
		.option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
		.handler(new ChannelInitializer<SocketChannel>() {
			@Override
			protected void initChannel(SocketChannel sc) throws Exception {
				sc.pipeline().addLast(new RPCConnection());
				sc.pipeline().addLast(new RPCRequestEncoder());
			}
		});
	}
	public void doConnect(){
		try {
			ChannelFuture future = bp.connect("127.0.0.1", 9999).sync();
			future.addListener(new ChannelFutureListener() {
				@Override
				public void operationComplete(ChannelFuture cf) throws Exception {
					if(cf.isSuccess()){
						
					}else{
						cf.channel().eventLoop().schedule(new Runnable() {
							@Override
							public void run() {
								doConnect();
							}
						}, 3, TimeUnit.SECONDS);
					}
				}
			});
			con = future.channel().pipeline().get(RPCConnection.class);
			int i = 0;
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public Object BuildClient(Class<?> interfaces,String host,int port){
		return Proxy.newProxyInstance(RPCConsumer.class.getClassLoader(), new Class<?>[]{interfaces}, 
				new InvocationHandler() {
					@Override
					public Object invoke(Object proxy, Method method, Object[] args)
							throws Throwable {
						//1. DoConnect
						//2. Send Request
						//3. Receive Information
						//4. change to RPCResponse
						//5. return
						RPCRequest request = new RPCRequest();
						request.setMothodName(method.getName());
						request.setParamTypes(method.getParameterTypes());
						request.setParamVals(args);
						con.SendMessage(request);
						return null;
					}
				});
	}
	
	
}
