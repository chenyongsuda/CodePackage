package com.sk.IF;

public interface UserServiceIF {
	public String test();
	public User getUser();
}
