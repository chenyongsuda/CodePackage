package com.sk.IF;

public class Main {
	
	public static void main(String[] args) {
		RPCConsumer con = new RPCConsumer();
		UserServiceIF userIF = (UserServiceIF)con.BuildClient(UserServiceIF.class, "127.0.0.1", 9999);
		userIF.test();
	}

}
