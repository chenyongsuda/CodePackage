package com.sk.IF;

import java.util.concurrent.TimeUnit;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.AdaptiveRecvByteBufAllocator;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoop;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;

public class RPCProvider {
	private ServerBootstrap sbp;
	private int port;
	//Public Service
	public void PublicService(Object service, int port){
		this.port = port;
		//1.Init Netty Server
		NioEventLoopGroup bossGroup = new NioEventLoopGroup();
		NioEventLoopGroup childGroup = new NioEventLoopGroup();
		sbp = new ServerBootstrap();
		sbp.group(bossGroup, childGroup)
		.channel(NioServerSocketChannel.class)
		.option(ChannelOption.SO_BACKLOG, 200)
		.option(ChannelOption.TCP_NODELAY, true)
		.option(ChannelOption.RCVBUF_ALLOCATOR, new AdaptiveRecvByteBufAllocator(64,80,65535))
		.option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
		.childOption(ChannelOption.RCVBUF_ALLOCATOR, new AdaptiveRecvByteBufAllocator(64,80,65535))
		.childOption(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
		.childOption(ChannelOption.SO_SNDBUF, 1024)
		.childOption(ChannelOption.SO_RCVBUF, 1024)
		.childHandler(new ChannelInitializer<SocketChannel>() {
			@Override
			protected void initChannel(SocketChannel ch) throws Exception {
				ch.pipeline().addLast(new RPCRequestDecoder());
				ch.pipeline().addLast(new ServerChannelHandler());
			}
			
		});
		
		//2.DoBind
		doBind();
		
	}
	
	public void doBind(){
		sbp.bind(port).addListener(new ChannelFutureListener() {
			@Override
			public void operationComplete(ChannelFuture cf) throws Exception {
				if(!cf.isSuccess()){
					cf.channel().eventLoop().schedule(new Runnable() {
						@Override
						public void run() {
							doBind();
						}
					}, 10, TimeUnit.SECONDS);
				}
			}
		});
	}
}
