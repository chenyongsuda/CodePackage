package com.sk.IF;

public class Main {

	public static void main(String[] args) {
		UserServiceIF service = new UserServiceImpl();
		RPCProvider pr = new RPCProvider();
		pr.PublicService(service, 9999);
	}
}
