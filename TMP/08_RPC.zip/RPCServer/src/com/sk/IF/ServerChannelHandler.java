package com.sk.IF;

import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.ReferenceCountUtil;

public class ServerChannelHandler extends ChannelInboundHandlerAdapter{
	
	private Channel ch;
	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
//		super.channelActive(ctx);
		System.out.println(ctx.channel().remoteAddress() + " Active ");
		this.ch = ctx.channel();
		
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg)
			throws Exception {
		RPCRequest req = (RPCRequest)msg;
		System.out.println(req.getMothodName());
//		super.channelRead(ctx, msg);
//		try{
//		ByteBuf buf = (ByteBuf)msg;
//		while(buf.isReadable()){
//			System.out.print((char)buf.readByte());
//			System.out.flush();
//		}
//		}
//		finally{
//			ReferenceCountUtil.release(msg);
//		}
		
//		ctx.writeAndFlush(msg);
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
			throws Exception {
//		super.exceptionCaught(ctx, cause);
		
	}

	public void Close(){
		ch.close();
	}
	
	public boolean isActive(){
		return ch.isActive();
	}
	

}
