package com.sk.IF;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.util.List;

public class RPCRequestDecoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buff,
			List<Object> list) throws Exception {
		if(buff.readableBytes() < 4){
			return;
		}
		buff.markReaderIndex();
		int len = buff.readInt();
		if(buff.readableBytes() < len){
			buff.resetReaderIndex();
			return;
		}
		byte[] bytes=new byte[buff.readableBytes()];
		buff.readBytes(bytes);
		ByteArrayInputStream bis = new ByteArrayInputStream(bytes);        
        ObjectInputStream ois = new ObjectInputStream (bis);        
        Object obj = ois.readObject();      
        ois.close();   
        bis.close();
		list.add(obj);
	}

}
