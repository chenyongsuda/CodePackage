package com.sk.IF;

public class UserServiceImpl implements UserServiceIF{

	@Override
	public String test() {
		return "Hello World, Lets Go!!!";
	}

	@Override
	public User getUser() {
		User user = new User();
		user.setId(23);
		user.setName("Tony Chen");
		return user;
	}
	
}
