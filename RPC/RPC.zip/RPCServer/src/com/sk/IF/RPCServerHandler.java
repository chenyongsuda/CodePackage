package com.sk.IF;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.lang.reflect.Method;

public class RPCServerHandler extends ChannelInboundHandlerAdapter{
	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		// TODO Auto-generated method stub
//		super.channelInactive(ctx);
		System.out.println(ctx.channel().remoteAddress() + " Inactive ");
	}

	Object service;
	
	public RPCServerHandler(Object service){
		this.service = service;
	}
	
	private Channel ch;
	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
//		super.channelActive(ctx);
		System.out.println(ctx.channel().remoteAddress() + " Active ");
		this.ch = ctx.channel();
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg)
			throws Exception {
		RPCRequest req = (RPCRequest)msg;
		System.out.println(req.getMothodName());
		Method mod = service.getClass().getMethod(req.getMothodName(), req.getParamTypes());
		Object ret = mod.invoke(service, req.getParamVals());
		RPCResponse res = new RPCResponse();
		res.setRet(ret);
		res.setMessage("~~~111~~~222!!!");
		ch.writeAndFlush(res);
//		for(int i = 0; i < 100; i++){
//			Thread.sleep(5000);
////			System.out.println("Replay Message to Client!!!");
//			ch.writeAndFlush(res);
//		}
//		super.channelRead(ctx, msg);
//		try{
//		ByteBuf buf = (ByteBuf)msg;
//		while(buf.isReadable()){
//			System.out.print((char)buf.readByte());
//			System.out.flush();
//		}
//		}
//		finally{
//			ReferenceCountUtil.release(msg);
//		}
		
//		ctx.writeAndFlush(msg);
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
			throws Exception {
//		super.exceptionCaught(ctx, cause);
		
	}

	public void Close(){
		ch.close();
	}
	
	public boolean isActive(){
		return ch.isActive();
	}
	

}
