package com.sk.IF;

import java.io.Serializable;

public class RPCResponse implements Serializable{
	private static final long serialVersionUID = -6977402643848374752L;
	private int error_code;
	private Object ret;
	private String message;
	
	
	public int getError_code() {
		return error_code;
	}
	public void setError_code(int error_code) {
		this.error_code = error_code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Object getRet() {
		return ret;
	}
	public void setRet(Object ret) {
		this.ret = ret;
	}
	
}
