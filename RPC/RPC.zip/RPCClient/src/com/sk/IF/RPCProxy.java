package com.sk.IF;

public class RPCProxy {

}
