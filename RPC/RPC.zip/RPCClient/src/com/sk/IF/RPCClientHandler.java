package com.sk.IF;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

public class RPCClientHandler extends ChannelInboundHandlerAdapter{
	private RPCConsumer consumer;
	
	public RPCClientHandler(RPCConsumer consumer){
		this.consumer = consumer;
	}
	public void channelRead(ChannelHandlerContext ctx, Object msg)
			throws Exception {
//		super.channelRead(ctx, msg);
		consumer.setRep((RPCResponse)msg);
//		System.out.println(rep.getMessage());
		System.out.println("Response Comes");
		synchronized (consumer.getObj()) {
			System.out.println("Response Comes Free All wait");
			consumer.getObj().notifyAll();
		}
//		System.out.println("Client "+response.getMessage());
//		System.out.println("Client come ");
	}
}
