package com.sk.IF;

import java.io.Serializable;

public class RPCRequest implements Serializable{
	private static final long serialVersionUID = -6977402643848374751L;
	private String mothodName;
	private Class<?>[] paramTypes;
	private Object[] paramVals;
	
	public String getMothodName() {
		return mothodName;
	}
	public void setMothodName(String mothodName) {
		this.mothodName = mothodName;
	}
	public Class<?>[] getParamTypes() {
		return paramTypes;
	}
	public void setParamTypes(Class<?>[] paramTypes) {
		this.paramTypes = paramTypes;
	}
	public Object[] getParamVals() {
		return paramVals;
	}
	public void setParamVals(Object[] paramVals) {
		this.paramVals = paramVals;
	}
}
