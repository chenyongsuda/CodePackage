package com.sk.IF;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.AdaptiveRecvByteBufAllocator;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class RPCConsumer/* extends ChannelInboundHandlerAdapter*/{
	private RPCResponse rep;
	public RPCResponse getRep() {
		return rep;
	}
	public void setRep(RPCResponse rep) {
		this.rep = rep;
	}

	private final Object obj = new Object();
	public Object getObj() {
		return obj;
	}

	String domain;
	int port;
	
	public RPCConsumer(String domain, int port){
		this.domain = domain;
		this.port = port;
	}
	
	
	public RPCResponse SendMessage(RPCRequest req){
		NioEventLoopGroup childGroup = new NioEventLoopGroup();
		Bootstrap bp = new Bootstrap();
		try {
			//1. init Netty and send sync
			bp.group(childGroup)
			.channel(NioSocketChannel.class)
			.option(ChannelOption.TCP_NODELAY, true)
			.option(ChannelOption.SO_KEEPALIVE, true)
			.option(ChannelOption.RCVBUF_ALLOCATOR, new AdaptiveRecvByteBufAllocator(64,80,65535))
			.option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
			.handler(new ChannelInitializer<SocketChannel>() {
				@Override
				protected void initChannel(SocketChannel sc) throws Exception {
					sc.pipeline().addLast(new RPCResponseDecoder());
					sc.pipeline().addLast(new RPCRequestEncoder());
//					sc.pipeline().addLast(RPCConsumer.this);
					sc.pipeline().addLast(new RPCClientHandler(RPCConsumer.this));
				}
			});
			ChannelFuture fu= bp.connect(domain, port).sync();
			
			System.out.println("Waiting Outer::: ");
			/*
			 * IF Follow Code like,there will be waitting problem when execute writeAndFlush(req).sync();
			 * The Response is quick than synchronized (obj)
			 * 
			 * fu.channel().writeAndFlush(req).sync();
			 * synchronized (obj) {
				System.out.println("Waiting Inner::: ");
				obj.wait();
			   }
			 * 
			 * 
			 * 
			 */
			synchronized (obj) {
				fu.channel().writeAndFlush(req).sync();
				System.out.println("Waiting Inner::: ");
				obj.wait();
			}
			System.out.println("Wait Free::: "+rep.getMessage());
//			fu.channel().closeFuture().sync();
			return rep;
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally{
			childGroup.shutdownGracefully();
//			childGroup.shutdownGracefully().syncUninterruptibly();
		}
		return null;
	}
	
//	@Override
//	public void channelRead(ChannelHandlerContext ctx, Object msg)
//			throws Exception {
////		super.channelRead(ctx, msg);
//		rep = (RPCResponse)msg;
////		System.out.println(rep.getMessage());
//		synchronized (obj) {
//			obj.notifyAll();
//		}
////		System.out.println("Client "+response.getMessage());
////		System.out.println("Client come ");
//	}
	
//	@Override
//	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
//			throws Exception {
////		super.exceptionCaught(ctx, cause);
//	}
	
//	public void init(){
//		childGroup = new NioEventLoopGroup();
//		bp = new Bootstrap();
//		bp.group(childGroup)
//		.channel(NioSocketChannel.class)
//		.option(ChannelOption.TCP_NODELAY, true)
//		.option(ChannelOption.SO_KEEPALIVE, true)
//		.option(ChannelOption.RCVBUF_ALLOCATOR, new AdaptiveRecvByteBufAllocator(64,80,65535))
//		.option(ChannelOption.ALLOCATOR, PooledByteBufAllocator.DEFAULT)
//		.handler(new ChannelInitializer<SocketChannel>() {
//			@Override
//			protected void initChannel(SocketChannel sc) throws Exception {
//				sc.pipeline().addFirst(new ChannelInboundHandlerAdapter(){
//					@Override
//					public void channelInactive(ChannelHandlerContext ctx)
//							throws Exception {
//						super.channelInactive(ctx);
//						System.out.println("Client Inactive");
//						ctx.channel().eventLoop().schedule(new Runnable() {
//							@Override
//							public void run() {
//								doConnect();
//							}
//						}, 3, TimeUnit.SECONDS);
//					}
//					
//				});
//				
//				sc.pipeline().addLast(new RPCResponseDecoder());
//				sc.pipeline().addLast(new RPCRequestEncoder());
//				sc.pipeline().addLast(new RPCConnection());
//			}
//		});
//	}
	
//	public void doConnect(){
//		try {
//			System.out.println("Do Connect~~~");
//			ChannelFuture future;
////			future = bp.connect("127.0.0.1", 9999).sync();
//			future = bp.connect("127.0.0.1", 9999);
//			future.addListener(new ChannelFutureListener() {
//				@Override
//				public void operationComplete(ChannelFuture cf) throws Exception {
//					if(cf.isSuccess()){
//						System.out.println("Connect Success in ChannelFutureListener!!!");
//					}else{
//						System.out.println("Connect Failed in ChannelFutureListener!!!");
//						cf.channel().eventLoop().schedule(new Runnable() {
//							@Override
//							public void run() {
//								doConnect();
//							}
//						}, 3, TimeUnit.SECONDS);
//					}
//				}
//			});
//			con = future.channel().pipeline().get(RPCConnection.class);
////			future.channel().closeFuture().sync();
////			System.out.println("closed!!!");
//		} 
//		catch (Exception e) {
//			System.out.println("InterruptedException");
//			e.printStackTrace();
//			doConnect();
//		}finally{
////			childGroup.shutdownGracefully();
////			System.out.println("finally");
//		}
//	}
	
	public Object BuildClient(Class<?> interfaces){
		return Proxy.newProxyInstance(RPCConsumer.class.getClassLoader(), new Class<?>[]{interfaces}, 
				new InvocationHandler() {
					@Override
					public Object invoke(Object proxy, Method method, Object[] args)
							throws Throwable {
						//1. DoConnect
						//2. Send Request
						//3. Receive Information
						//4. change to RPCResponse
						//5. return
						RPCRequest request = new RPCRequest();
						request.setMothodName(method.getName());
						request.setParamTypes(method.getParameterTypes());
						request.setParamVals(args);
						RPCResponse psp = SendMessage(request);
						return psp.getRet();
					}
				});
	}


	
	
}
