package com.sk.IF;

public class Main {
	
	public static void main(String[] args) throws InterruptedException {
		RPCConsumer con = new RPCConsumer("127.0.0.1",9999);
		int count = 0;
		long ss = System.currentTimeMillis();
		for(int i =0; i <10000; i++){
			Thread.sleep(1);
			long startTime = System.currentTimeMillis();
			UserServiceIF userIF = (UserServiceIF)con.BuildClient(UserServiceIF.class);
			System.out.println("Client Say : " + userIF.test());
			System.out.println("Client Say : " + userIF.test());
			long endTime = System.currentTimeMillis();
			System.out.println(endTime-startTime);
			count++;
		}
		long ee = System.currentTimeMillis();
		System.out.println("finish!!! "+ count + " time:"+(ee-ss));
//		userIF.test();
//		Thread.sleep(1000);
//		con.close();
//		for(int i =0; i <100; i++){
//			Thread.sleep(3000);
////			userIF.test();
//			System.out.println("main Looping "+i);
//		}
	}

}
